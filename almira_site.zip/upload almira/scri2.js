// let aoneedit = document.getElementById('aoneedit');
// aoneedit.addEventListener(){}

function getselecteditem()
{
     var select = document.getElementById('select1');
     var select2 = document.getElementById('select2');
     let getamount = document.getElementById('getamount').value;

     if (select.options[select.selectedIndex].value == 'A1') {
     let aoneitem =  document.getElementById('aoneitem');
     let aoneviee =  document.getElementById('aoneview');
     let va = select2.options[select2.selectedIndex].value;
     aoneitem.innerHTML = va;
     aoneviee.innerHTML = getamount;
     document.getElementById('aoneinp').value = getamount;
    let input= document.getElementById("aoneinp");
    localStorage.setItem("aoneinp",input.value);
    let storedValue = localStorage.getItem("aoneinp");
    document.getElementById("aoneview").innerHTML = storedValue;

    document.getElementById('aoneiteminp').value = va;
    let input1= document.getElementById("aoneiteminp");
    localStorage.setItem("aoneiteminp",input1.value);
    let storedValue1 = localStorage.getItem("aoneiteminp");
    document.getElementById("aoneitem").innerHTML = storedValue1;
    document.getElementById("aonelist").innerHTML = storedValue1;
    document.getElementById("aonelist").innerHTML = storedValue1;
}

    else if (select.options[select.selectedIndex].value == 'A2') {
     let atwoitem =  document.getElementById('atwoitem');
     let atwoviee =  document.getElementById('atwoview');
     let ca = select2.options[select2.selectedIndex].value;
     atwoitem.innerHTML = ca;
     atwoviee.innerHTML = getamount;
     document.getElementById('atwoinp').value = getamount;
    let input= document.getElementById("atwoinp");
    localStorage.setItem("atwoinp",input.value);
    let storedValue = localStorage.getItem("atwoinp");
    document.getElementById("atwoview").innerHTML = storedValue;

    document.getElementById('atwoiteminp').value = ca;
    let input1= document.getElementById("atwoiteminp");
    localStorage.setItem("atwoiteminp",input1.value);
    let storedValue1 = localStorage.getItem("atwoiteminp");
    document.getElementById("atwoitem").innerHTML = storedValue1;
    document.getElementById("atwolist").innerHTML = storedValue1;
    } 
    else if (select.options[select.selectedIndex].value == 'A3') {
     let athreeitem =  document.getElementById('athreeitem');
     let athreeviee =  document.getElementById('athreeview');
     let la = select2.options[select2.selectedIndex].value;
     athreeitem.innerHTML = la;
     athreeviee.innerHTML = getamount;
     document.getElementById('athreeinp').value = getamount;
    let input= document.getElementById("athreeinp");
    localStorage.setItem("athreeinp",input.value);
    let storedValue = localStorage.getItem("athreeinp");
    document.getElementById("athreeview").innerHTML = storedValue;

    document.getElementById('athreeiteminp').value = la;
    let input1= document.getElementById("athreeiteminp");
    localStorage.setItem("athreeiteminp",input1.value);
    let storedValue1 = localStorage.getItem("athreeiteminp");
    document.getElementById("athreeitem").innerHTML = storedValue1;
    document.getElementById("athreelist").innerHTML = storedValue1;
    }
    else if (select.options[select.selectedIndex].value == 'B1') {
   	 let boneitem =  document.getElementById('boneitem');
     let boneviee =  document.getElementById('boneview');
     let sa = select2.options[select2.selectedIndex].value;
     boneitem.innerHTML = sa;
     boneviee.innerHTML = getamount;
     document.getElementById('boneinp').value = getamount;
    let input= document.getElementById("boneinp");
    localStorage.setItem("boneinp",input.value);
    let storedValue = localStorage.getItem("boneinp");
    document.getElementById("boneview").innerHTML = storedValue;

    document.getElementById('boneiteminp').value = sa;
    let input1= document.getElementById("boneiteminp");
    localStorage.setItem("boneiteminp",input1.value);
    let storedValue1 = localStorage.getItem("boneiteminp");
    document.getElementById("boneitem").innerHTML = storedValue1;
    document.getElementById("bonelist").innerHTML = storedValue1;
    }
    else if (select.options[select.selectedIndex].value == 'B2') {
     let btwoitem =  document.getElementById('btwoitem');
     let btwoviee =  document.getElementById('btwoview');
     let za = select2.options[select2.selectedIndex].value;
     btwoitem.innerHTML = za;
     btwoviee.innerHTML = getamount;
     document.getElementById('btwoinp').value = getamount;
    let input= document.getElementById("btwoinp");
    localStorage.setItem("btwoinp",input.value);
    let storedValue = localStorage.getItem("btwoinp");
    document.getElementById("btwoview").innerHTML = storedValue;

    document.getElementById('btwoiteminp').value = za;
    let input1= document.getElementById("btwoiteminp");
    localStorage.setItem("btwoiteminp",input1.value);
    let storedValue1 = localStorage.getItem("btwoiteminp");
    document.getElementById("btwoitem").innerHTML = storedValue1;
    document.getElementById("btwolist").innerHTML = storedValue1;
    }
    else if (select.options[select.selectedIndex].value == 'B3') {
     let bthreeitem =  document.getElementById('bthreeitem');
     let bthreeviee =  document.getElementById('bthreeview');
     let ua = select2.options[select2.selectedIndex].value;
     bthreeitem.innerHTML = ua;
     bthreeviee.innerHTML = getamount;
     document.getElementById('bthreeinp').value = getamount;
    let input= document.getElementById("bthreeinp");
    localStorage.setItem("bthreeinp",input.value);
    let storedValue = localStorage.getItem("bthreeinp");
    document.getElementById("bthreeview").innerHTML = storedValue;

    document.getElementById('bthreeiteminp').value = ua;
    let input1= document.getElementById("bthreeiteminp");
    localStorage.setItem("bthreeiteminp",input1.value);
    let storedValue1 = localStorage.getItem("bthreeiteminp");
    document.getElementById("bthreeitem").innerHTML = storedValue1;
    document.getElementById("bthreelist").innerHTML = storedValue1;
    }
    return false;
}

function togglesidebar(){
	document.getElementById('sidebar').classList.toggle('active');
}

function showdropitem(){
	const value = document.getElementById('select2').value;
	document.getElementById('choice2').innerHTML = `You have choose ${value}`;
	
    const textinput = document.getElementById('getitem').value;
    document.getElementById('items').innerHTML = `${textinput}`;
    document.getElementById('getitem').innerHTML = '';
	return value;
	}

function showdropvalue(){
	const value = document.getElementById('select1').value;
	document.getElementById('choice').innerHTML = `You have choose ${value}`;
	document.getElementById('so').innerHTML = `${value}`;

	return value;
	}


function form(){
	document.getElementById('click').innerHTML = `you have selected locker number ${showdropvalue()}`;
	document.getElementById('boxnumber').innerHTML = `${showdropvalue()}`;
	return false;
	}
