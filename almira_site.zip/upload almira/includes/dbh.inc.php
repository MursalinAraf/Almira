<?php

	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "almira";

	$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

?>