let shirtbox = document.getElementById('shirtbox');
let shirtnumber = document.getElementById('shirtnumber');

function frockbarbe(){
	let frockerkaj = document.getElementById('frockerkaj').value;
	frockerkaj++;
	document.getElementById('frockerkaj').value = frockerkaj;
	
}
function frockkombe(){
	let frockerkaj = document.getElementById('frockerkaj').value;
	if (frockerkaj > 0) {
	frockerkaj--;
	document.getElementById('frockerkaj').value = frockerkaj;
	}
}

function beltbarbe(){
	let belterkaj = document.getElementById('belterkaj').value;
	belterkaj++;
	document.getElementById('belterkaj').value = belterkaj;
	
}
function beltkombe(){
	let belterkaj = document.getElementById('belterkaj').value;
	if (belterkaj > 0) {
	belterkaj--;
	document.getElementById('belterkaj').value = belterkaj;
	}
}

function shoebarbe(){
	let shoeerkaj = document.getElementById('shoeerkaj').value;
	shoeerkaj++;
	document.getElementById('shoeerkaj').value = shoeerkaj;
	
}
function shoekombe(){
	let shoeerkaj = document.getElementById('shoeerkaj').value;
	if (shoeerkaj > 0) {
	shoeerkaj--;
	document.getElementById('shoeerkaj').value = shoeerkaj;
	}
}

function sockbarbe(){
	let sockerkaj = document.getElementById('sockerkaj').value;
	sockerkaj++;
	document.getElementById('sockerkaj').value = sockerkaj;
	
}
function sockkombe(){
	let sockerkaj = document.getElementById('sockerkaj').value;
	if (sockerkaj > 0) {
	sockerkaj--;
	document.getElementById('sockerkaj').value = sockerkaj;
	}
}

function pantbarbe(){
	let panterkaj = document.getElementById('panterkaj').value;
	panterkaj++;
	document.getElementById('panterkaj').value = panterkaj;
}

function pantkombe(){
	let panterkaj = document.getElementById('panterkaj').value;
	if (panterkaj > 0) {
	panterkaj--;
	document.getElementById('panterkaj').value = panterkaj;
	}
}

function shirtbarbe(){
	let shirterkaj = document.getElementById('shirterkaj').value;
	shirterkaj++;
	document.getElementById('shirterkaj').value = shirterkaj;
}
function shirtkombe(){
	let shirterkaj = document.getElementById('shirterkaj').value;
	if (shirterkaj > 0) {
	shirterkaj--;
	document.getElementById('shirterkaj').value = shirterkaj;
	}
}

function shirtupdate(){
	shirtnumber.innerHTML = document.getElementById('shirterkaj').value;
	shirtnumber.value = document.getElementById('shirterkaj').value;
	let input= document.getElementById("shirtnumber");
    localStorage.setItem("shirtnumber",input.value);
}
function pantupdate(){
	pantnumber.innerHTML = document.getElementById('panterkaj').value;
	pantnumber.value = document.getElementById('panterkaj').value;
	let input= document.getElementById("pantnumber");
    localStorage.setItem("pantnumber",input.value);
}
function sockupdate(){
	socknumber.innerHTML = document.getElementById('sockerkaj').value;
	socknumber.value = document.getElementById('sockerkaj').value;
	let input= document.getElementById("socknumber");
    localStorage.setItem("socknumber",input.value);
}
function shoeupdate(){
	shoenumber.innerHTML = document.getElementById('shoeerkaj').value;
	shoenumber.value = document.getElementById('shoeerkaj').value;
	let input= document.getElementById("shoenumber");
    localStorage.setItem("shoenumber",input.value);
}
function beltupdate(){
	beltnumber.innerHTML = document.getElementById('belterkaj').value;
	beltnumber.value = document.getElementById('belterkaj').value;
	let input= document.getElementById("beltnumber");
    localStorage.setItem("beltnumber",input.value);
}
function frockupdate(){
	frocknumber.innerHTML = document.getElementById('frockerkaj').value;
	frocknumber.value = document.getElementById('frockerkaj').value;
	let input= document.getElementById("frocknumber");
    localStorage.setItem("frocknumber",input.value);
}

function localshirt(){
	document.getElementById('id01').style.display='block';
	 let storedValue = localStorage.getItem("shirtnumber");
    document.getElementById("shirtnumber").innerHTML = storedValue;
    document.getElementById("shirterkaj").value = storedValue;
}

function localpant(){
	document.getElementById('id02').style.display='block';
	 let storedValue = localStorage.getItem("pantnumber");
    document.getElementById("pantnumber").innerHTML = storedValue;
    document.getElementById("panterkaj").value = storedValue;
}

function localsock(){
	document.getElementById('id03').style.display='block';
	 let storedValue = localStorage.getItem("socknumber");
    document.getElementById("socknumber").innerHTML = storedValue;
    document.getElementById("sockerkaj").value = storedValue;
}

function localshoe(){
	document.getElementById('id04').style.display='block';
	 let storedValue = localStorage.getItem("shoenumber");
    document.getElementById("shoenumber").innerHTML = storedValue;
    document.getElementById("shoeerkaj").value = storedValue;
}

function localbelt(){
	document.getElementById('id05').style.display='block';
	 let storedValue = localStorage.getItem("beltnumber");
    document.getElementById("beltnumber").innerHTML = storedValue;
    document.getElementById("belterkaj").value = storedValue;
}

function localfrock(){
	document.getElementById('id06').style.display='block';
	 let storedValue = localStorage.getItem("frocknumber");
    document.getElementById("frocknumber").innerHTML = storedValue;
    document.getElementById("frockerkaj").value = storedValue;
}