window.onload = function(){
		document.onkeydown = function(e){
			return (e.which || e.keyCode) != 116;
		};
	}

const searchitem = document.getElementById('searchitem');
const gobutton = document.getElementById('go');
gobutton.addEventListener('click',function(){
	if (searchitem.value == 'shoe' ||  searchitem.value == 'SHOE') {
		document.getElementById('lekha').innerHTML = `shoe is in box B1 and shoe number is ${Valuebone}`;
		document.getElementById('home').style.display = 'visible';
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
	else if (searchitem.value == 'shirt' ||  searchitem.value == 'SHIRT') {
		document.getElementById('lekha').innerHTML = `shirt is in A1 and number is ${Valueaone}`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
	else if (searchitem.value == 'pant' ||  searchitem.value == 'PANT') {
		document.getElementById('lekha').innerHTML = `pant is in box A2 and pant number is ${Valueatwo}`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
	else if (searchitem.value == 'sock' ||  searchitem.value == 'SOCK') {
		document.getElementById('lekha').innerHTML = `sock is in box A3 and sock number is ${Valueathree}`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display (= 'none';)
	}
	else if (searchitem.value == 'belt' ||  searchitem.value == 'BELT') {
		document.getElementById('lekha').innerHTML = `belt is in box B2 and belt number is ${Valuebtwo}`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
	else if (searchitem.value == 'frock' ||  searchitem.value == 'FROCK') {
		document.getElementById('lekha').innerHTML = `frock is in box B3 and frock number is ${Valuebthree}`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
	else{
		document.getElementById('lekha').innerHTML = `No similaiar item`;
		// document.getElementById('visibility').style.display = 'none';
		// document.getElementById('visibility1').style.display = 'none';
		// document.getElementById('porergula').style.display = 'none';
	}
})

function shirtinc(){
	let foo = document.getElementById('aoneboxcount').innerHTML;
	foo++;
	document.getElementById('aoneboxcount').innerHTML = foo;
	 document.getElementById("aoneinp").value = foo;
	////////////////////////////////////////////////////////
	let saveone = document.getElementById('saveone');
	saveone.addEventListener('click',function(){

	let input= document.getElementById("aoneinp");
    localStorage.setItem("aoneinp",input.value);
    let storedValue = localStorage.getItem("aoneinp");
    document.getElementById("aoneview").innerHTML = storedValue;
});	

	 return foo -1;
}

	let showone = document.getElementById('showone');
	showone.addEventListener('click',function(){
	Valueaone = localStorage.getItem("aoneinp");
    document.getElementById("aoneview").innerHTML = Valueaone;
    document.getElementById("aoneinp").value = Valueaone;

    Valueaoneone = localStorage.getItem("aoneiteminp");
    document.getElementById("aoneitem").innerHTML = Valueaoneone;
    document.getElementById("aoneiteminp").value = Valueaoneone;
	});

function shirtdec(){
	let foo = document.getElementById('aoneboxcount').innerHTML;
	if (foo>0) {
	foo--;
	document.getElementById('aoneboxcount').innerHTML = foo;
	document.getElementById("aoneinp").value = foo;
}
}	

function pantinc(){
	let coo = document.getElementById('atwoboxcount').innerHTML;
	coo++;
	document.getElementById('atwoboxcount').innerHTML = coo;
	document.getElementById("atwoinp").value = coo;
	let savetwo = document.getElementById('savetwo');
	savetwo.addEventListener('click',function(){

	let input= document.getElementById("atwoinp");
    localStorage.setItem("atwoinp",input.value);
    let storedValue = localStorage.getItem("atwoinp");
    document.getElementById("atwoview").innerHTML = storedValue;
});

	return coo -1;
}

let showtwo = document.getElementById('showtwo');
	showtwo.addEventListener('click',function(){
	Valueatwo = localStorage.getItem("atwoinp");
    document.getElementById("atwoview").innerHTML = Valueatwo;
    document.getElementById("atwoinp").value = Valueatwo;

    Valueatwotwo = localStorage.getItem("atwoiteminp");
    document.getElementById("atwoitem").innerHTML = Valueatwotwo;
    document.getElementById("atwoiteminp").value = Valueatwotwo;
	});


function pantdec(){
	let coo = document.getElementById('atwoboxcount').innerHTML;
	if (coo>0) {
	coo--;
	document.getElementById('atwoboxcount').innerHTML = coo;
	document.getElementById("atwoinp").value = coo;
}
}

function sockinc(){
	let moo = document.getElementById('athreeboxcount').innerHTML;
	moo++;
	document.getElementById('athreeboxcount').innerHTML = moo;
	document.getElementById("athreeinp").value = moo;
	let savethree = document.getElementById('savethree');
	savethree.addEventListener('click',function(){

	let input= document.getElementById("athreeinp");
    localStorage.setItem("athreeinp",input.value);
    let storedValue = localStorage.getItem("athreeinp");
    document.getElementById("athreeview").innerHTML = storedValue;
});
	return moo -1;
}

let showthree = document.getElementById('showthree');
	showthree.addEventListener('click',function(){
	Valueathree = localStorage.getItem("athreeinp");
    document.getElementById("athreeview").innerHTML = Valueathree;
    document.getElementById("athreeinp").value = Valueathree;

    Valueathreethree = localStorage.getItem("athreeiteminp");
    document.getElementById("athreeitem").innerHTML = Valueathreethree;
    document.getElementById("athreeiteminp").value = Valueathreethree;
	});

function sockdec(){
	let moo = document.getElementById('athreeboxcount').innerHTML;
	if (moo>0) {
	moo--;
	document.getElementById('athreeboxcount').innerHTML = moo;
	document.getElementById("athreeinp").value = moo;
}
}

function shoeinc(){
	let too = document.getElementById('boneboxcount').innerHTML;
	too++;
	document.getElementById('boneboxcount').innerHTML = too;
	document.getElementById("boneinp").value = too;
	let savebone = document.getElementById('savebone');
	savebone.addEventListener('click',function(){

	let input= document.getElementById("boneinp");
    localStorage.setItem("boneinp",input.value);
    let storedValue = localStorage.getItem("boneinp");
    document.getElementById("boneview").innerHTML = storedValue;
});
	return too -1;
}

let showbone = document.getElementById('showbone');
	showbone.addEventListener('click',function(){
	Valuebone = localStorage.getItem("boneinp");
    document.getElementById("boneview").innerHTML = Valuebone;
    document.getElementById("boneinp").value = Valuebone;

    Valueboneone = localStorage.getItem("boneiteminp");
    document.getElementById("boneitem").innerHTML = Valueboneone;
    document.getElementById("boneiteminp").value = Valueboneone;
	});

function shoedec(){
	let too = document.getElementById('boneboxcount').innerHTML;
	if (too>0) {
	too--;
	document.getElementById('boneboxcount').innerHTML = too;
	document.getElementById("boneinp").value = too;
}
}

function beltinc(){
	let voo = document.getElementById('btwoboxcount').innerHTML;
	voo++;
	document.getElementById('btwoboxcount').innerHTML = voo;
	document.getElementById("btwoinp").value = voo;
	let savebtwo = document.getElementById('savebtwo');
	savebtwo.addEventListener('click',function(){

	let input= document.getElementById("btwoinp");
    localStorage.setItem("btwoinp",input.value);
    let storedValue = localStorage.getItem("btwoinp");
    document.getElementById("btwoview").innerHTML = storedValue;
});
	return voo -1;
}

let showbtwo = document.getElementById('showbtwo');
	showbtwo.addEventListener('click',function(){
	Valuebtwo = localStorage.getItem("btwoinp");
    document.getElementById("btwoview").innerHTML = Valuebtwo;
    document.getElementById("athreeinp").value = Valuebtwo;

    Valuebtwotwo = localStorage.getItem("btwoiteminp");
    document.getElementById("btwoitem").innerHTML = Valuebtwotwo;
    document.getElementById("btwoiteminp").value = Valuebtwotwo;
	});

function beltdec(){
	let voo = document.getElementById('btwoboxcount').innerHTML;
	if (voo>0) {
	voo--;
	document.getElementById('btwoboxcount').innerHTML = voo;
	document.getElementById("btwoinp").value = voo;
}
}

function frockinc(){
	let loo = document.getElementById('bthreeboxcount').innerHTML;
	loo++;
	document.getElementById('bthreeboxcount').innerHTML = loo;
	document.getElementById("bthreeinp").value = loo;
	let savebthree = document.getElementById('savebthree');
	savebthree.addEventListener('click',function(){

	let input= document.getElementById("bthreeinp");
    localStorage.setItem("bthreeinp",input.value);
    let storedValue = localStorage.getItem("bthreeinp");
    document.getElementById("bthreeview").innerHTML = storedValue;
});
	return loo -1;
}

let showbthree = document.getElementById('showbthree');
	showbthree.addEventListener('click',function(){
	Valuebthree = localStorage.getItem("bthreeinp");
    document.getElementById("bthreeview").innerHTML = Valuebthree;
    document.getElementById("bthreeinp").value = Valuebthree;

    Valuebthreethree = localStorage.getItem("bthreeiteminp");
    document.getElementById("bthreeitem").innerHTML = Valuebthreethree;
    document.getElementById("bthreeiteminp").value = Valuebthreethree;
	});

function frockdec(){
	let loo = document.getElementById('bthreeboxcount').innerHTML;
	if (loo>0) {
	loo--;
	document.getElementById('bthreeboxcount').innerHTML = loo;
	document.getElementById("bthreeinp").value = loo;
}
}